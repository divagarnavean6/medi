const logs = [
  {
    label: 'New document added',
    time: '14:12',
    color: 'border-theme-1',
    key: 0
  },
  {
    label: 'New document added',
    time: '13:20',
    color: 'border-theme-2',
    key: 1
  },
  {
    label: 'Document accessed',
    time: '12:55',
    color: 'border-danger',
    key: 2
  },
  {
    label: 'New document added',
    time: '12:44',
    color: 'border-theme-2',
    key: 3
  }
]
export default logs
