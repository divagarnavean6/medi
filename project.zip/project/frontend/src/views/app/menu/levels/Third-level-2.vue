<template>
<div>
    <b-row>
        <b-colxx xxs="12">
            <piaf-breadcrumb :heading="$t('menu.third-level-2')" />
            <div class="separator mb-5"></div>
        </b-colxx>
    </b-row>
    <b-row>
        <b-colxx xxs="12">
             <p>{{$t('menu.third-level-2')}}</p>
        </b-colxx>
    </b-row>
</div>
</template>
